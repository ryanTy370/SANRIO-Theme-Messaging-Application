import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.security.*;

public class Main {
    private static final int PORT = 8080;
    private static final Set<ClientHandler> clients = new CopyOnWriteArraySet<>();
    private static final Map<String, User> users = new ConcurrentHashMap<>();
    private static ServerSocket serverSocket;
    private static ExecutorService pool = Executors.newCachedThreadPool();

    public static void main(String[] args) {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                if (serverSocket != null) serverSocket.close();
                pool.shutdown();
                System.out.println("Server shutdown gracefully");
            } catch (IOException e) {
                System.err.println("Error during shutdown: " + e.getMessage());
            }
        }));

        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("Sanrio Chat Server is running on port " + PORT);
            
            while (!serverSocket.isClosed()) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler clientThread = new ClientHandler(clientSocket);
                clients.add(clientThread);
                pool.execute(clientThread);
            }
        } catch (IOException e) {
            System.err.println("Server exception: " + e.getMessage());
            restartServer();
        }
    }

    private static void restartServer() {
        System.out.println("Attempting to restart server...");
        try {
            Thread.sleep(5000);
            main(new String[]{});
        } catch (Exception e) {
            System.err.println("Failed to restart server: " + e.getMessage());
        }
    }
    
    public static void broadcast(String message, ClientHandler excludeClient) {
        for (ClientHandler client : clients) {
            if (client != excludeClient && !client.socket.isClosed()) {
                client.sendMessage(message);
            }
        }
    }
    
    public static void removeClient(ClientHandler client, String username) {
        try {
            if (client != null) {
                clients.remove(client);
                if (!client.socket.isClosed()) {
                    client.socket.close();
                }
            }
            if (username != null) {
                users.remove(username);
                broadcastUserList();
            }
        } catch (IOException e) {
            System.err.println("Error removing client: " + e.getMessage());
        }
    }
    
    public static void addUser(String username, String avatar, String character) {
        if (username != null && !username.trim().isEmpty()) {
            users.put(username, new User(username, avatar, character));
            broadcastUserList();
        }
    }
    
    private static void broadcastUserList() {
        JSONObject userListMessage = new JSONObject();
        userListMessage.put("type", "userList");
        userListMessage.put("users", new JSONArray(users.keySet()));
        userListMessage.put("count", users.size());
        
        String message = userListMessage.toString();
        broadcast(message, null);
    }
    
    private static class ClientHandler implements Runnable {
        private Socket socket;
        private InputStream in;
        private OutputStream out;
        private String username;
        private boolean running = true;

        public ClientHandler(Socket socket) {
            try {
                this.socket = socket;
                this.socket.setKeepAlive(true);
                this.socket.setSoTimeout(0);
                this.in = socket.getInputStream();
                this.out = socket.getOutputStream();
                
                if (!handleHandshake()) {
                    throw new IOException("WebSocket handshake failed");
                }
            } catch (IOException e) {
                System.err.println("Error creating client handler: " + e.getMessage());
                running = false;
                removeClient(this, null);
            }
        }

        private boolean handleHandshake() throws IOException {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line = reader.readLine();
            
            // Validate initial request line
            if (line == null || !line.startsWith("GET ")) {
                sendHttpResponse(400, "Bad Request");
                return false;
            }

            String wsKey = null;
            boolean isWebSocket = false;
            boolean isUpgrade = false;
            
            // Read headers
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                if (line.startsWith("Sec-WebSocket-Key:")) {
                    wsKey = line.substring("Sec-WebSocket-Key:".length()).trim();
                }
                if (line.toLowerCase().startsWith("upgrade:") && line.toLowerCase().contains("websocket")) {
                    isWebSocket = true;
                }
                if (line.toLowerCase().startsWith("connection:") && line.toLowerCase().contains("upgrade")) {
                    isUpgrade = true;
                }
            }

            // Validate required headers
            if (wsKey == null || !isWebSocket || !isUpgrade) {
                sendHttpResponse(400, "Bad Request");
                return false;
            }

            // Send WebSocket handshake response
            String response = "HTTP/1.1 101 Switching Protocols\r\n" +
                             "Upgrade: websocket\r\n" +
                             "Connection: Upgrade\r\n" +
                             "Sec-WebSocket-Accept: " + generateAcceptKey(wsKey) + "\r\n\r\n";
            out.write(response.getBytes("UTF-8"));
            out.flush();
            return true;
        }

        private void sendHttpResponse(int statusCode, String statusMessage) throws IOException {
            String response = "HTTP/1.1 " + statusCode + " " + statusMessage + "\r\n\r\n";
            out.write(response.getBytes("UTF-8"));
            out.flush();
        }

        private String generateAcceptKey(String key) {
            try {
                String magic = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
                MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
                sha1.update((key + magic).getBytes("UTF-8"));
                return Base64.getEncoder().encodeToString(sha1.digest());
            } catch (Exception e) {
                throw new RuntimeException("Failed to generate WebSocket key", e);
            }
        }

        @Override
        public void run() {
            try {
                while (running && !socket.isClosed()) {
                    byte[] header = new byte[2];
                    int bytesRead = in.read(header);
                    if (bytesRead == -1) break;
                    
                    int opcode = header[0] & 0x0F;
                    int payloadLength = header[1] & 0x7F;
                    
                    if (payloadLength == 126) {
                        byte[] extended = new byte[2];
                        in.read(extended);
                        payloadLength = ((extended[0] & 0xFF) << 8) | (extended[1] & 0xFF);
                    } else if (payloadLength == 127) {
                        byte[] extended = new byte[8];
                        in.read(extended);
                        payloadLength = (int) ((extended[0] & 0xFFL) << 56 | 
                                             (extended[1] & 0xFFL) << 48 | 
                                             (extended[2] & 0xFFL) << 40 | 
                                             (extended[3] & 0xFFL) << 32 | 
                                             (extended[4] & 0xFFL) << 24 | 
                                             (extended[5] & 0xFFL) << 16 | 
                                             (extended[6] & 0xFFL) << 8 | 
                                             (extended[7] & 0xFFL));
                    }
                    
                    byte[] maskingKey = new byte[4];
                    in.read(maskingKey);
                    
                    byte[] payload = new byte[payloadLength];
                    int totalRead = 0;
                    while (totalRead < payloadLength) {
                        int read = in.read(payload, totalRead, payloadLength - totalRead);
                        if (read == -1) break;
                        totalRead += read;
                    }
                    
                    // Unmask payload
                    for (int i = 0; i < payloadLength; i++) {
                        payload[i] ^= maskingKey[i % 4];
                    }
                    
                    if (opcode == 0x1) { // Text frame
                        handleMessage(new String(payload, "UTF-8"));
                    } else if (opcode == 0x8) { // Close frame
                        sendCloseFrame();
                        break;
                    } else if (opcode == 0x9) { // Ping frame
                        sendPongFrame(payload);
                    }
                }
            } catch (SocketTimeoutException e) {
                System.out.println("Client timeout: " + username);
            } catch (Exception e) {
                System.err.println("Client error (" + username + "): " + e.getMessage());
            } finally {
                removeClient(this, username);
            }
        }
        
        private void handleMessage(String message) {
            try {
                JSONObject json = parseJson(message);
                if (json == null) return;
                
                String type = json.getString("type");
                switch (type) {
                    case "message":
                        broadcast(message, this);
                        break;
                    case "userUpdate":
                        this.username = json.getString("name");
                        String avatar = json.getString("avatar");
                        String character = json.getString("character");
                        addUser(username, avatar, character);
                        break;
                }
            } catch (Exception e) {
                System.err.println("Error handling message: " + e.getMessage());
            }
        }

        public void sendMessage(String message) {
            try {
                if (socket.isClosed()) return;
                
                byte[] payload = message.getBytes("UTF-8");
                ByteArrayOutputStream frame = new ByteArrayOutputStream();
                
                frame.write(0x81); // Text frame (FIN + opcode)
                if (payload.length <= 125) {
                    frame.write(payload.length);
                } else if (payload.length <= 65535) {
                    frame.write(126);
                    frame.write((payload.length >> 8) & 0xFF);
                    frame.write(payload.length & 0xFF);
                } else {
                    frame.write(127);
                    for (int i = 7; i >= 0; i--) {
                        frame.write((payload.length >> (8 * i)) & 0xFF);
                    }
                }
                frame.write(payload);
                
                out.write(frame.toByteArray());
                out.flush();
            } catch (IOException e) {
                System.err.println("Error sending message to " + username + ": " + e.getMessage());
                removeClient(this, username);
            }
        }
        
        private void sendCloseFrame() throws IOException {
            byte[] closeFrame = new byte[] { (byte) 0x88, 0x00 };
            out.write(closeFrame);
            out.flush();
            running = false;
        }
        
        private void sendPongFrame(byte[] payload) throws IOException {
            ByteArrayOutputStream frame = new ByteArrayOutputStream();
            frame.write(0x8A); // Pong frame
            frame.write(payload.length);
            frame.write(payload);
            out.write(frame.toByteArray());
            out.flush();
        }
        
        private JSONObject parseJson(String jsonString) {
            try {
                jsonString = jsonString.trim();
                if (!jsonString.startsWith("{") || !jsonString.endsWith("}")) {
                    return null;
                }
                
                JSONObject json = new JSONObject();
                String content = jsonString.substring(1, jsonString.length() - 1).trim();
                if (content.isEmpty()) return json;
                
                String[] pairs = content.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                for (String pair : pairs) {
                    String[] keyValue = pair.split(":(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", 2);
                    if (keyValue.length == 2) {
                        String key = keyValue[0].trim().replaceAll("^\"|\"$", "");
                        String value = keyValue[1].trim().replaceAll("^\"|\"$", "");
                        json.put(key, value);
                    }
                }
                return json;
            } catch (Exception e) {
                System.err.println("JSON parse error: " + jsonString);
                return null;
            }
        }
    }
    
    static class User {
        String name;
        String avatar;
        String character;
        
        public User(String name, String avatar, String character) {
            this.name = name;
            this.avatar = avatar;
            this.character = character;
        }
    }
    
    static class JSONObject {
        private Map<String, Object> map = new HashMap<>();
        
        public void put(String key, Object value) {
            if (key != null && value != null) {
                map.put(key, value);
            }
        }
        
        public String getString(String key) {
            Object value = map.get(key);
            return (value instanceof String) ? (String) value : null;
        }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            boolean first = true;
            
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (!first) sb.append(",");
                first = false;
                
                sb.append("\"").append(entry.getKey()).append("\":");
                
                if (entry.getValue() instanceof String) {
                    sb.append("\"").append(entry.getValue()).append("\"");
                } else if (entry.getValue() instanceof JSONArray) {
                    sb.append(entry.getValue().toString());
                } else {
                    sb.append(entry.getValue());
                }
            }
            
            sb.append("}");
            return sb.toString();
        }
    }
    
    static class JSONArray {
        private Collection<?> collection;
        
        public JSONArray(Collection<?> collection) {
            this.collection = collection;
        }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            
            for (Object item : collection) {
                if (!first) sb.append(",");
                first = false;
                
                if (item instanceof String) {
                    sb.append("\"").append(item).append("\"");
                } else {
                    sb.append(item);
                }
            }
            
            sb.append("]");
            return sb.toString();
        }
    }
}