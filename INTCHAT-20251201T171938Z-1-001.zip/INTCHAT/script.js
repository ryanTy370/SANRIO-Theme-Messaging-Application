document.addEventListener('DOMContentLoaded', function() {
    // User configuration
    let currentUser = {
        name: '',
        avatar: 'assets/images/kitty-avatar.png',
        character: 'kitty'
    };

    // WebSocket connection
    const socket = new WebSocket('ws://localhost:8080/chat');

    // DOM elements
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const messageContainer = document.getElementById('message-container');
    const usernameInput = document.getElementById('username');
    const userAvatar = document.getElementById('user-avatar');
    const userList = document.getElementById('user-list');
    const characterImages = document.querySelectorAll('.character');
    const emojiButtons = document.querySelectorAll('.emoji');
    const messageSound = document.getElementById('message-sound');
    const emojiPicker = document.querySelector('.emoji-picker');
    const emojiDropdown = document.getElementById('emoji-dropdown');

    // Character avatars mapping
    const characterAvatars = {
        kitty: 'assets/images/kitty-avatar.png',
        mymelody: 'assets/images/mymelody-avatar.png',
        kuromi: 'assets/images/kuromi-avatar.png',
        cinnamoroll: 'assets/images/cinnamoroll-avatar.png'
    };

    // Character colors mapping
    const characterColors = {
        kitty: '#ff9ff3',
        mymelody: '#fdcfe8',
        kuromi: '#a56cc1',
        cinnamoroll: '#7ac9f0'
    };

    // Set up character selection
    characterImages.forEach(character => {
        character.addEventListener('click', function() {
            // Remove active class from all characters
            characterImages.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked character
            this.classList.add('active');
            
            // Update user's avatar
            const characterType = this.getAttribute('data-character');
            currentUser.character = characterType;
            userAvatar.src = characterAvatars[characterType];
            
            // Update user info on server if name is set
            if (currentUser.name) {
                updateUserInfo();
            }
        });
    });

    // Set up emoji picker toggle
    emojiPicker.addEventListener('click', function() {
        emojiDropdown.style.display = emojiDropdown.style.display === 'block' ? 'none' : 'block';
    });

    // Add selected emoji to message input
    emojiDropdown.addEventListener('click', function(e) {
        if (e.target.classList.contains('emoji')) {
            const emoji = e.target.getAttribute('data-emoji');
            messageInput.value += emoji;

            // Close the dropdown after selecting emoji
            emojiDropdown.style.display = 'none';

            // Remove focus from the input to prevent the "I" cursor
            messageInput.blur();
        }
    });

    // Close emoji picker if clicking outside
    document.addEventListener('click', function(e) {
        if (!emojiPicker.contains(e.target) && !emojiDropdown.contains(e.target)) {
            emojiDropdown.style.display = 'none';
        }
    });

    // Update username when changed
    usernameInput.addEventListener('change', function() {
        currentUser.name = this.value.trim();
        if (currentUser.name) {
            updateUserInfo();
        }
    });

    // Send message when button is clicked or Enter is pressed
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // WebSocket event handlers
    socket.onopen = function() {
        console.log('Connected to chat server');
    };

    socket.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        if (data.type === 'message') {
            displayMessage(data);
            playNotificationSound();
        } else if (data.type === 'userList') {
            updateUserList(data.users);
        } else if (data.type === 'userUpdate') {
            // Handle user updates if needed
        }
    };

    socket.onclose = function() {
        console.log('Disconnected from chat server');
        displaySystemMessage('Disconnected from server. Trying to reconnect...');
        setTimeout(() => {
            window.location.reload();
        }, 3000);
    };

    // Function to send message
    function sendMessage() {
        const message = messageInput.value.trim();
        if (message && currentUser.name) {
            const messageData = {
                type: 'message',
                user: currentUser.name,
                avatar: currentUser.avatar,
                character: currentUser.character,
                content: message,
                timestamp: new Date().toISOString()
            };
            
            socket.send(JSON.stringify(messageData));
            messageInput.value = '';
            
            // Display message immediately on sender's side
            displayMessage({
                ...messageData,
                isCurrentUser: true
            });
        }
    }

    // Function to display message
    function displayMessage(data) {
        const messageElement = document.createElement('div');
        messageElement.className = `message ${data.isCurrentUser ? 'user-message' : 'other-message'}`;
        
        // Set background color based on character
        if (!data.isCurrentUser && data.character && characterColors[data.character]) {
            messageElement.style.backgroundColor = characterColors[data.character];
        }
        
        const time = new Date(data.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageElement.innerHTML = ` 
            <div class="message-info">
                <img src="${data.avatar}" alt="${data.user}" class="message-avatar">
                <span class="message-username">${data.user}</span>
                <span class="message-time">${time}</span>
            </div>
            <div class="message-content">${data.content}</div>
        `;
        
        messageContainer.appendChild(messageElement);
        messageElement.scrollIntoView({ behavior: 'smooth' });
        
        // Add bounce effect for new messages
        if (!data.isCurrentUser) {
            messageElement.classList.add('new-message-notification');
            setTimeout(() => {
                messageElement.classList.remove('new-message-notification');
            }, 1000);
        }
    }

    // Function to display system messages
    function displaySystemMessage(text) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message system-message';
        messageElement.textContent = text;
        messageContainer.appendChild(messageElement);
        messageElement.scrollIntoView({ behavior: 'smooth' });
    }

    // Function to update user list
    function updateUserList(users) {
        userList.innerHTML = '';
        users.forEach(user => {
            if (user !== currentUser.name) { // Don't show current user in the list
                const li = document.createElement('li');
                li.textContent = user;
                userList.appendChild(li);
            }
        });
    }

    // Function to update user info on server
    function updateUserInfo() {
        const userData = {
            type: 'userUpdate',
            name: currentUser.name,
            avatar: currentUser.avatar,
            character: currentUser.character
        };
        socket.send(JSON.stringify(userData));
    }

    // Function to play notification sound
    function playNotificationSound() {
        messageSound.currentTime = 0;
        messageSound.play().catch(e => console.log('Audio play failed:', e));
    }

    // Initialize with default character
    userAvatar.src = characterAvatars.kitty;
    
    // Display welcome message
    displaySystemMessage('Welcome to Sanrio Chat! Choose your character and set your name to start chatting.');

    // Add floating effects
    createFloatingElements('star', 20);
    createFloatingElements('heart', 15);

    function createFloatingElements(type, count) {
        const container = document.querySelector('.chat-area');
        
        for (let i = 0; i < count; i++) {
            const element = document.createElement('div');
            element.className = `floating-${type}`;
            element.innerHTML = type === 'star' ? '★' : '♥';
            
            // Random properties
            const size = Math.random() * 20 + 10;
            const duration = Math.random() * 20 + 10;
            const delay = Math.random() * 5;
            const left = Math.random() * 100;
            const opacity = Math.random() * 0.5 + 0.1;
            
            // Apply styles
            element.style.position = 'absolute';
            element.style.fontSize = `${size}px`;
            element.style.color = type === 'star' ? '#ffd700' : '#ff6b8b';
            element.style.left = `${left}%`;
            element.style.top = '-30px';
            element.style.opacity = opacity;
            element.style.pointerEvents = 'none';
            element.style.zIndex = '-1';
            element.style.animation = `float-${type} ${duration}s linear ${delay}s infinite`;
            
            container.appendChild(element);
        }
    }

    // Add keyframes dynamically
    const style = document.createElement('style');
    style.textContent = ` 
        @keyframes float-star {
            0% { transform: translateY(0) rotate(0deg); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(calc(100vh + 30px)) rotate(360deg); opacity: 0; }
        }

        @keyframes float-heart {
            0% { transform: translateY(0) scale(1); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(calc(100vh + 30px)) scale(1.5); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
});

